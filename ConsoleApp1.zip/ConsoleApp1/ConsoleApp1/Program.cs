﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //SecondLargestfromArray();
            //RemoveDublicate();
            //var result = ParticularCharCountFromString("gopal", 'G');
            //EachCharCountFromString();//Count the occurrence of each character in a string
            var str = ReverseString();
            //DublicateCharinStringAndCount("");
            //var ss = EvenorAdd(3);
        }

        //Check if a string contains only digits
        //str.All(char.IsDigit);

        //remove all white spaces from a string c#
        //string stringWithoutSpaces = originalString.Replace(" ", ""); 

        private static void CountOFString()
        {
            string input = "Gopal";
            int Count = 0;
            foreach (char c in input)
            {
                Count++;
              }

            Console.WriteLine(Count);
        }
        private static void RemoveDublicate()
        {
            Console.Write("Enter a String : ");
            string inputString = Console.ReadLine();
            string resultString = string.Empty;
            for (int i = 0; i < inputString.Length; i++)
            {
                if (!resultString.Contains(inputString[i]))
                {
                    resultString += inputString[i];
                }
            }
            Console.WriteLine(resultString);
            Console.ReadKey();
        }
        private static int ParticularCharCountFromString(string source, char toFind)
        {
            int count = 0;
            for (int i = 0; i < source.Length; i++)
            {
                if (source[i] == toFind)
                    count++;
            }
            return count;

        }
        private static void EachCharCountFromString()
        {
            Console.Write("Enter the string : ");
            string message = Console.ReadLine();
            //Remove the empty spaces from the message
            message = message.Replace(" ", string.Empty);

            while (message.Length > 0)
            {
                Console.Write(message[0] + " : ");
                int count = 0;
                for (int j = 0; j < message.Length; j++)
                {
                    if (message[0] == message[j])
                    {
                        count++;
                    }
                }
                Console.WriteLine(count);
                message = message.Replace(message[0].ToString(), string.Empty);
            }
            Console.ReadKey();
        }
        private static string ReverseString()
        {
            //Simple way
            //string reverse = "";
            //foreach (char c in "gopal priya")
            //{
            //    reverse = c + reverse;
            //}
            //Console.WriteLine(reverse);
            //
            //Another way by loop
            string input = "hello gopal";
            string reversed = "";
            //How to reverse the order of words in a given string?input:hello gopal oyt : gopal hello
            //string[] words = input.Split(' ');
            for (int i = input.Length - 1; i >= 0; i--)
            {
                reversed += input[i];
                //if (i > 0)
                //    reversed += " ";
            }
            return reversed;

            //How to reverse each word in a given string?
            //string input1 = "Hello World This is C#";
            //string[] words = input1.Split(' ');

            //foreach (string word in words)
            //{
            //    // print characters in reverse order
            //    for (int i = word.Length - 1; i >= 0; i--)
            //    {
            //        Console.Write(word[i]);
            //    }
            //    Console.Write(" "); // space between words
            //}


            //another program palindrome 
            //if(input==reverse)
            //{
            //    //true
            //}
        }
        private static string EvenorAdd(int num)
        {
            if (num % 2 == 0)
                return "evenNumber";
            else
                return "OddNumber";
        }
        private static void DublicateCharinStringAndCount(string inputString)
        {
            int[] count = new int[256];

            Console.WriteLine(
                "Duplicate characters in the string and their counts are:");

            foreach (char c in inputString)
            {
                count[c]++;
            }

            for (int i = 0; i < 256; i++)
            {
                if (count[i] > 1)
                {
                    Console.WriteLine($"Character: {(char)i}, Count: {count[i]}");

                }
            }
        }
        private static void SwapTwonumber()
        {
            int a = 10; int b=5;
            a = a + b;
            b = a - b;
            a = a - b;
        }
    }
}

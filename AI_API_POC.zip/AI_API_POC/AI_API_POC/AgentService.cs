﻿using Microsoft.SemanticKernel;
using System.Text;
using System.Text.Json;

namespace AI_API_POC
{
    public class AgentService
    {
        //private readonly Kernel _kernel;

        //public AgentService(Kernel kernel)
        //{
        //    _kernel = kernel;
        //}

        //public async Task<string> RunAgent(string userGoal)
        //{
        //    var prompt = $"""
        //You are an AI agent.
        //Goal: {userGoal}

        //Break this into steps and solve it.
        //""";

        //    var result = await _kernel.InvokePromptAsync(prompt);
        //    return result.ToString();
        //}

        private readonly HttpClient _httpClient;

        public AgentService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<string> RunAgent(string userGoal)
        {
            var request = new
            {
                model = "tinyllama",
                prompt = $"You are an AI agent. Goal: {userGoal}",
                stream = false
            };

            var content = new StringContent(
                JsonSerializer.Serialize(request),
                Encoding.UTF8,
                "application/json"
            );

            var response = await _httpClient.PostAsync(
                "http://localhost:11434/api/generate",
                content
            );

            return await response.Content.ReadAsStringAsync();
        }
    }
}
    
using AI_API_POC;
using Microsoft.SemanticKernel;

var builder = WebApplication.CreateBuilder(args);
var apiKey = builder.Configuration["OpenAI:ApiKey"];
Console.WriteLine($"API KEY VALUE: {apiKey}");

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<Kernel>(sp =>
{
    var kernelBuilder = Kernel.CreateBuilder();

    //kernelBuilder.AddOpenAIChatCompletion(
    //    modelId: "gpt-4o-mini",
    //    apiKey: "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"
    //);

    return kernelBuilder.Build();
});
builder.Services.AddScoped<AgentService>();
builder.Services.AddHttpClient<AgentService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
